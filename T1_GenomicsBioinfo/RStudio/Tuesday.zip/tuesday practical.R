west<- read.csv("western_banded_gecko.csv", header=FALSE, stringsAsFactors = FALSE, colClasses = rep("character",len))
